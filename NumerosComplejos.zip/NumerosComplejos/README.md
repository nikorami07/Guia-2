# Calculadora de numeros complejos

En este repositorio encontrara una libreria hecha en java donde su función es actuar como calculadora de números complejos

## Requisitos de uso

Para utilizar dicha libreria se debe tener instalado algún IDE (Netbeans, Eclipse etc), además de contar con los archivos que se encuentran en este repositorio

### Instalación

Para instalar y ejecutar esta libreria lo que debe hacer es ejecutar algún IDE y desde ahí abrir los archivos para ejecutarlo.

### Utilidades: Basado en el libro Quantum Computing for Computing Scientists se cuenta con las siguientes funciones.

    Capítulos 1 y 2:
    Suma
    Producto
    Resta
    División
    Módulo
    Conjugado
    Conversión entre representaciones polar y cartesiano
    Retornar la fase de un número complejo.
    



## Authors

* **Andrés Quintero** 

