package Pruebas;

import NumerosComplejos.*;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 *
 * @author Andrés Quintero
 */
public class NumerosComplejosTest {

    @Test
    void sumaTest() {
        NumerosComplejos a = new NumerosComplejos(5, -1);
        NumerosComplejos b = new NumerosComplejos(4, -3);
        NumerosComplejos r = ComplexMath.suma(a, b);
        NumerosComplejos r2 = new NumerosComplejos(9, -4);
        assertEquals(r.getParteReal(), 9.0);
        assertEquals(r.getParteImgaginaria(), -4.0);
        assertTrue(r.equals(r2));
    }

    @Test
    void productoTest() {
        NumerosComplejos a = new NumerosComplejos(5, -1);
        NumerosComplejos b = new NumerosComplejos(4, -3);
        NumerosComplejos r = ComplexMath.producto(a, b);
        assertEquals(r.getReal(), 17.0);
        assertEquals(r.getImg(), -19.0);
    }

    @Test
    void moduloTest() {
        NumerosComplejos c = new NumerosComplejos(5, -1);
        assertEquals(c.modulo(), 5.0990195135927845);
    }

    @Test
    void conjugadoTest() {
        NumerosComplejos a = new NumerosComplejos(5, -1);
        NumerosComplejos r = a.conjugado();
        assertTrue(r.equals(new NumerosComplejos(5, 1)));
    }

}
